#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

//--------------------------------------------------------------------
// Tree structure

struct node {
    bool is_red;
    int value;
    struct node* parent;
    struct node* lchild;
    struct node* rchild;
};

typedef struct node Node;

//--------------------------------------------------------------------
// Tree nodes manipulation

Node* new_node(bool is_red, int value) {
    Node* node = (Node*)malloc(sizeof(Node));
    node->value = value;
    node->is_red = is_red;
    node->parent = NULL;
    node->lchild = NULL;
    node->rchild = NULL;
    return node;
}

void attach_left(Node* parent, Node* child) {
    // attach node child (or nothing) as left child of node parent
    // parent should NEVER be NULL, but child can be NULL
    if (parent->lchild) {
        parent->lchild->parent = NULL;
    }
    parent->lchild = child;

    if (child) {
        if (child->parent) {
            if (child->parent->lchild == child) {
                child->parent->lchild = NULL;
            } else {
                child->parent->rchild = NULL;
            }
        }
        child->parent = parent;
    }
}

void attach_right(Node* parent, Node* child) {
    // attach node child (or nothing) as right child of node parent
    // parent should NEVER be NULL, but child can be NULL
    if (parent->rchild) {
        parent->rchild->parent = NULL;
    }
    parent->rchild = child;

    if (child) {
        if (child->parent) {
            if (child->parent->lchild == child) {
                child->parent->lchild = NULL;
            } else {
                child->parent->rchild = NULL;
            }
        }
        child->parent = parent;
    }
}

//--------------------------------------------------------------------
// General tree functions

int size(Node* tree) {
    // Returns the size of the tree

    return 0; // à compléter
}

int get_values(Node* tree, int array[]) {
    // Put all values stored in the tree in the array
    // the values should be ordered as infix depth-first search
    //
    // The function returns the number of values written

    return 0; // à compléter
}

void disp_node(Node* node) {
    if (node) {
        if (node->is_red) {
            printf("\033[101mR %d\033[0m", node->value);
        } else {
            printf("\033[100mB %d\033[0m", node->value);
        }
    } else {
        printf("None");
    }
}

int width_node(int v) {
    int w = 2;
    if (v<=0) { w++; }
    while (v) { w++; v/=10; }
    return w;
}

bool disp_tree_depth(Node* node, int p) {
    bool res = false;
    if (!node) { return false; }
    res = disp_tree_depth(node->lchild, p-1) || res;
    if (!p) {
        disp_node(node);
        res = true;
    } else {
        for (int i=0; i<width_node(node->value); ++i) { printf(" "); }
    }
    res = disp_tree_depth(node->rchild, p-1) || res;
    return res;
}

void disp_tree(Node* node) {
    // Display a red-black tree in terminal
    if (!node) {
        printf("Empty tree\n");
        return;
    }
    bool goon = true;
    for (int i=0; goon; i++) {
        goon = disp_tree_depth(node, i);
        printf("\n");
    }
}

void disp_values(Node* tree) {
    // Display values of a binary tree
    // This function depends on functions size and get_values!
    // For binary search trees, the values should be non-decreasing

    int nb = size(tree);
    int* tab = (int*)malloc(nb*sizeof(int));
    if (tab) {
        get_values(tree, tab);
        printf("Values = [ ");
        for (int i=0; i<nb; ++i) { printf("%d ", tab[i]); }
        printf("]\n");
        free(tab);
    }
}

bool is_bst(Node* tree) {
    // Returns true if the tree is a valid BST
    // returns false otherwise
    // Note : empty tree (NULL) is a valid BST

    return false; // à compléter
}

//--------------------------------------------------------------------
// Moving in the tree

Node* parent(Node* node) {
    // returns pointer to parent if possible
    // returns NULL if node is NULL or tree is root
    if (!node) { return NULL; }
    return node->parent;
}

Node* lchild(Node* node) {
    // returns pointer to left child if there's one
    // returns NULL if node is NULL or no left child

    return NULL; // à compléter
}

Node* rchild(Node* node) {
    // returns pointer to right child if there's one
    // returns NULL if node is NULL or no right child

    return NULL; // à compléter
}

Node* brother(Node* node) {
    // returns pointer to brother if there's one
    // returns NULL if node is NULL or has no brother

    return NULL; // à compléter
}

Node* greatparent(Node* node) {
    // returns pointer to great-parent if there's one
    // returns NULL if node is NULL or has no great-parent

    return NULL; // à compléter
}

Node* uncle(Node* node) {
    // returns pointer to uncle if there's one
    // returns NULL if node is NULL or has no uncle

    return NULL; // à compléter
}

//--------------------------------------------------------------------
// Testing the tree

bool is_root(Node* node) {
    // returns true if node is the root of the tree
    // returns false otherwise
    return node && node->parent == NULL;
}

bool is_left_child(Node* node) {
    // returns tree if node is left child of it
    return node && lchild(parent(node)) == node;
}

bool is_right_child(Node* node) {
    return node && rchild(parent(node)) == node;
}

bool is_red_node(Node* node) {
    return node && node->is_red;
}

bool is_black_node(Node* tree) {
    return tree && !tree->is_red;
}

//--------------------------------------------------------------------
// Example of tree

struct rbdata { char type; int value; };

Node* build_tree(struct rbdata data[], int n) {
    Node* stack = NULL;
    for (int i=0; i<n; ++i) {
        if (data[i].type == 'X') {
            Node* node = new_node(false, 0);
            node->lchild = node;
            node->parent = stack;
            stack = node;
        } else {
            Node* node = new_node(data[i].type == 'R', data[i].value);
            node->rchild = stack;
            stack = node->rchild->parent;
            if (node->rchild->lchild == node->rchild) {
                free(node->rchild);
                node->rchild=NULL;
            } else {
                node->rchild->parent = node;
            }
            node->lchild = stack;
            stack = node->lchild->parent;
            if (node->lchild->lchild == node->lchild) {
                free(node->lchild);
                node->lchild=NULL;
            } else {
                node->lchild->parent = node;
            }
            node->parent=stack;
            stack=node;
        }
    }
    return stack;
}

struct rbdata ex_tree_data[] = { {'X',0}, {'X',0}, {'R',1}, {'X',0}, {'B',4}, {'X',0}, {'X',0}, {'R',10}, {'X',0}, {'X',0}, {'R',14}, {'B',11}, {'B',9}, {'X',0}, {'X',0}, {'B',22}, {'X',0}, {'X',0}, {'X',0}, {'R',29}, {'B',25}, {'X',0}, {'X',0}, {'X',0}, {'R',54}, {'B',42}, {'R',37}, {'B',23}, {'B',17} };

//--------------------------------------------------------------------
// Red-black trees constraints

bool has_double_red(Node* tree) {
    // return true if and only if there's a red node with a red parent

    return false; // à compléter
}

int black_height(Node* tree) {
    // Returns black height if correct, -1 if incorrect

    return 0; // à compléter
}

bool is_rb_tree(Node* tree) {
    return false; // à modifier
}

//--------------------------------------------------------------------
// Search

Node* find(Node* tree, int value) {
    // returns pointer to node in tree whose label equals value
    // returns NULL if no such node exists

    return NULL; // à compléter
}

bool mem(Node* tree, int value) {
    // returns true if there's a node whose label equals value
    // returns false if there's none

    return false; // à compléter
}

//--------------------------------------------------------------------
// Add

void repair_red(Node* node) {
    // Repair the tree whose node belongs to
    // node should be a red node that may not have a black parent

    // à compléter
}

Node* add(Node* tree, int value) {
    return tree; // à compléter
}

//--------------------------------------------------------------------
// Remove

//--------------------------------------------------------------------
// Main program

int main(void) {
    Node* ex_tree = build_tree(ex_tree_data,
                          sizeof(ex_tree_data)/sizeof(struct rbdata));
    disp_tree(ex_tree);
    return 0;
}

