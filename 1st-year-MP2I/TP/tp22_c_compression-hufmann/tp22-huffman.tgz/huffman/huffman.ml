(* Types pour les fichiers binaires *)

type outbitfile = {
  file : out_channel;
  mutable buff : int };;

type inbitfile = {
  data : string;
  mutable pos : int };;

(* Fonctions pour les fichiers *)

let open_bit_out filename =
   { file = open_out filename; buff = 1 };;

let output_bit fd b =
  fd.buff <- fd.buff*2 + (if b then 1 else 0);
  if fd.buff >= 64 then
    begin
      output_string fd.file (String.make 1 (char_of_int (fd.buff-32)));
      fd.buff <- 1;
    end;;

let close_bit_out fd =
  while fd.buff <> 1 do output_bit fd false done;
  close_out fd.file;;

(* Fonctions pour la relecture *)

let open_bit_in filename =
  let fd = open_in filename in
  let data = input_line fd in
    close_in fd; { data = data; pos = 0 };;

let read_bit fd =
  let i = fd.pos / 6 in
  let k = int_of_char (fd.data.[i]) - 32 in
  let b = k land (1 lsl (5 - fd.pos mod 6)) <> 0 in
  fd.pos <- fd.pos + 1; b;;

(* Fonctions pour lire le contenu d'un fichier texte *)

let read_file filename = 
  let f = open_in filename in
  let txt = ref [] in
    try
      while true do txt := input_line f :: !txt done; ""
    with End_of_file -> String.concat "\n" (List.rev !txt);;

(* Encodage de Huffman *)

type tree = Leaf of int*int | Node of int;;


